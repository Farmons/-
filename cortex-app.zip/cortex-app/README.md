# CORTEX

Прототип голосового ассистента (веб-версия) и сборка APK через GitHub Actions.

## Как закинуть на GitHub
1. Создайте новый репозиторий на github.com (пустой, без README).
2. Нажмите **Add file → Upload files** и перетащите ВСЕ файлы и папки из архива
   (папки `www` и `.github` тоже; если `.github` не виден, включите показ скрытых файлов).
3. Нажмите **Commit changes**.

## Сайт (GitHub Pages)
Settings → Pages → Source: **GitHub Actions**. После пуша сайт откроется по адресу
`https://ВАШ_ЛОГИН.github.io/ИМЯ_РЕПО/`.

## APK
Вкладка **Actions → Build APK → Run workflow**. Через 5–8 минут скачайте файл
`cortex-apk` из раздела Artifacts, распакуйте zip и установите `app-debug.apk`.
