package com.musicmover

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Item(val ref: PlaylistRef, val selected: Boolean)

val SERVICE_NAMES = mapOf("vk" to "VK Музыка", "yandex" to "Яндекс Музыка", "spotify" to "Spotify", "file" to "Файл")

class MainVM(app: Application) : AndroidViewModel(app) {
    val store = Store(app)
    var tick by mutableIntStateOf(0)
    var loginFor by mutableStateOf<String?>(null)
    var src by mutableStateOf<String?>(null)
    var dst by mutableStateOf<String?>(null)
    var lists by mutableStateOf<List<Item>>(emptyList())
    var busy by mutableStateOf(false)
    var fileText by mutableStateOf<String?>(null)
    var spClient by mutableStateOf(store.get("sp_client") ?: "")
    val log = mutableStateListOf<String>()

    fun connected(id: String): Boolean = when (id) {
        "vk" -> store.get("vk_token") != null
        "yandex" -> store.get("ya_token") != null
        "file" -> fileText != null
        else -> store.get("sp_refresh") != null
    }

    fun service(id: String): MusicService = when (id) {
        "vk" -> VkService(store.get("vk_token")!!)
        "yandex" -> YandexService(store.get("ya_token")!!)
        "file" -> FileService(fileText!!)
        else -> SpotifyService(store)
    }

    fun logout(id: String) {
        when (id) {
            "vk" -> store.remove("vk_token")
            "yandex" -> store.remove("ya_token")
            else -> store.remove("sp_access", "sp_refresh", "sp_exp")
        }
        if (src == id) { src = null; lists = emptyList() }
        if (dst == id) dst = null
        tick++
    }

    fun onToken(id: String, token: String) {
        store.put(if (id == "vk") "vk_token" else "ya_token", token)
        loginFor = null
        tick++
    }

    fun onSpotifyRedirect(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try { SpotifyAuth.finish(store, uri); log += "Spotify: вход выполнен" }
            catch (e: Exception) { log += "Spotify: ошибка входа — ${e.message}" }
            tick++
        }
    }

    fun toggle(i: Int) {
        lists = lists.mapIndexed { idx, it -> if (idx == i) it.copy(selected = !it.selected) else it }
    }

    fun loadLists() {
        val s = src ?: return
        viewModelScope.launch {
            busy = true
            try {
                val l = withContext(Dispatchers.IO) { service(s).playlists() }
                lists = (if (s == "file") emptyList() else listOf(Item(PlaylistRef(null, "Избранное"), false))) + l.map { Item(it, false) }
            } catch (e: Exception) {
                log += "Ошибка загрузки плейлистов: ${e.message}"
            }
            busy = false
        }
    }

    fun run() {
        val s = src ?: return
        val d = dst ?: return
        val chosen = lists.filter { it.selected }
        if (chosen.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            busy = true
            try {
                val from = service(s); val to = service(d)
                val notFound = mutableListOf<String>()
                for (item in chosen) {
                    val likes = item.ref.id == null
                    log += "▶ ${item.ref.name}"
                    val tracks = from.read(item.ref.id)
                    log += "  треков: ${tracks.size}"
                    val matched = mutableListOf<Track>()
                    tracks.forEachIndexed { i, t ->
                        val m = try { Matcher.best(t, to.search("${t.artist} ${t.title}".trim())) } catch (e: Exception) { null }
                        if (m != null) matched += m else notFound += "${item.ref.name}: ${t.artist} - ${t.title}"
                        if ((i + 1) % 25 == 0) log += "  … ${i + 1}/${tracks.size}"
                        Thread.sleep(200)
                    }
                    if (matched.isNotEmpty()) to.save(matched, item.ref.name, likes)
                    log += "  ✓ перенесено ${matched.size} из ${tracks.size}"
                }
                if (notFound.isNotEmpty()) {
                    log += "Не найдено (${notFound.size}):"
                    notFound.forEach { log += "✗ $it" }
                }
                log += "Готово"
            } catch (e: Exception) {
                log += "Ошибка: ${e.message}"
            }
            busy = false
        }
    }
}
