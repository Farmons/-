package com.musicmover

/** Источник из текстового файла: «Исполнитель - Название», плейлисты отделяются строкой «# Название». */
class FileService(private val text: String) : MusicService {
    private fun parse(): Map<String, List<Track>> {
        val sections = linkedMapOf<String, MutableList<Track>>()
        var cur = ""
        sections[cur] = mutableListOf()
        for (raw in text.lines()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (line.startsWith("# ")) {
                cur = line.substring(2).trim()
                sections.getOrPut(cur) { mutableListOf() }
                continue
            }
            val idx = line.indexOf(" - ")
            val t = if (idx >= 0) Track(line.substring(0, idx).trim(), line.substring(idx + 3).trim())
            else Track("", line)
            sections.getOrPut(cur) { mutableListOf() } += t
        }
        return sections
    }

    override suspend fun playlists(): List<PlaylistRef> =
        parse().filter { it.value.isNotEmpty() }.keys.map { PlaylistRef(it, it.ifEmpty { "Без названия" }) }

    override suspend fun read(pid: String?): List<Track> {
        val s = parse()
        return if (pid == null) s.values.flatten() else s[pid].orEmpty()
    }

    override suspend fun search(q: String): List<Track> = throw UnsupportedOperationException("Файл — только источник")
    override suspend fun save(tracks: List<Track>, name: String, likes: Boolean) =
        throw UnsupportedOperationException("Файл — только источник")
}
