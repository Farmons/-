package com.musicmover

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.security.MessageDigest
import java.security.SecureRandom

object SpotifyAuth {
    const val REDIRECT = "musicmover://spotify"
    private const val SCOPE = "user-library-read user-library-modify playlist-read-private playlist-modify-private"

    fun start(ctx: Context, store: Store, clientId: String) {
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~"
        val rnd = SecureRandom()
        val verifier = (1..64).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
        store.put("sp_verifier", verifier)
        store.put("sp_client", clientId)
        val challenge = Base64.encodeToString(
            MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray()),
            Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP,
        )
        val url = Http.url(
            "https://accounts.spotify.com/authorize",
            "client_id" to clientId, "response_type" to "code", "redirect_uri" to REDIRECT,
            "scope" to SCOPE, "code_challenge_method" to "S256", "code_challenge" to challenge,
        )
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun save(store: Store, o: JSONObject) {
        store.put("sp_access", o.getString("access_token"))
        if (o.has("refresh_token")) store.put("sp_refresh", o.getString("refresh_token"))
        store.put("sp_exp", (System.currentTimeMillis() + o.getLong("expires_in") * 1000 - 60_000).toString())
    }

    fun finish(store: Store, uri: Uri) {
        val code = uri.getQueryParameter("code")
            ?: throw IOException("Spotify: ${uri.getQueryParameter("error") ?: "нет кода авторизации"}")
        val o = Http.obj(
            "POST", "https://accounts.spotify.com/api/token",
            form = mapOf(
                "grant_type" to "authorization_code", "code" to code, "redirect_uri" to REDIRECT,
                "client_id" to (store.get("sp_client") ?: ""), "code_verifier" to (store.get("sp_verifier") ?: ""),
            ),
        )
        save(store, o)
    }

    fun token(store: Store): String {
        val exp = store.get("sp_exp")?.toLongOrNull() ?: 0L
        if (System.currentTimeMillis() > exp) {
            val o = Http.obj(
                "POST", "https://accounts.spotify.com/api/token",
                form = mapOf(
                    "grant_type" to "refresh_token", "refresh_token" to (store.get("sp_refresh") ?: ""),
                    "client_id" to (store.get("sp_client") ?: ""),
                ),
            )
            save(store, o)
        }
        return store.get("sp_access") ?: throw IOException("Spotify: нет токена")
    }
}

class SpotifyService(private val store: Store) : MusicService {
    private val api = "https://api.spotify.com/v1"
    private fun h() = mapOf("Authorization" to "Bearer ${SpotifyAuth.token(store)}")

    private fun conv(t: JSONObject): Track? {
        val id = t.optString("id").ifEmpty { return null }
        val artists = t.optJSONArray("artists")
        val names = (0 until (artists?.length() ?: 0)).joinToString(", ") { artists!!.getJSONObject(it).optString("name") }
        return Track(names, t.optString("name"), t.optInt("duration_ms") / 1000, id)
    }

    private fun pages(first: String): List<JSONObject> {
        val out = mutableListOf<JSONObject>()
        var url: String? = first
        while (url != null) {
            val o = Http.obj("GET", url, h())
            out += o
            url = if (o.isNull("next")) null else o.optString("next").ifEmpty { null }
        }
        return out
    }

    override suspend fun playlists(): List<PlaylistRef> =
        pages(Http.url("$api/me/playlists", "limit" to "50")).flatMap { p ->
            val items = p.optJSONArray("items") ?: JSONArray()
            (0 until items.length()).map { items.getJSONObject(it) }
        }.map { PlaylistRef(it.getString("id"), it.getString("name")) }

    override suspend fun read(pid: String?): List<Track> {
        val first = if (pid == null) Http.url("$api/me/tracks", "limit" to "50")
        else Http.url("$api/playlists/$pid/items", "limit" to "100")
        return pages(first).flatMap { p ->
            val items = p.optJSONArray("items") ?: JSONArray()
            (0 until items.length()).mapNotNull {
                val e = items.getJSONObject(it)
                // после февраля 2026 поле называется "item", раньше — "track"
                val t = e.optJSONObject("item") ?: e.optJSONObject("track")
                if (t == null) null else conv(t)
            }
        }
    }

    override suspend fun search(q: String): List<Track> {
        val o = Http.obj("GET", Http.url("$api/search", "q" to q, "type" to "track", "limit" to "10"), h())
        val items = o.optJSONObject("tracks")?.optJSONArray("items") ?: return emptyList()
        return (0 until items.length()).mapNotNull { conv(items.getJSONObject(it)) }
    }

    override suspend fun save(tracks: List<Track>, name: String, likes: Boolean) {
        val uris = tracks.mapNotNull { it.id }.map { "spotify:track:$it" }
        if (likes) {
            uris.chunked(40).forEach {
                Http.request("PUT", Http.url("$api/me/library", "uris" to it.joinToString(",")), h())
            }
            return
        }
        val pl = Http.obj("POST", "$api/me/playlists", h(),
            json = JSONObject().put("name", name).put("public", false).toString())
        val id = pl.getString("id")
        uris.chunked(100).forEach {
            Http.request("POST", "$api/playlists/$id/items", h(),
                json = JSONObject().put("uris", JSONArray(it)).toString())
        }
    }
}
