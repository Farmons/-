package com.musicmover

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

private const val VK_URL = "https://oauth.vk.com/authorize?client_id=2685278&display=mobile" +
    "&redirect_uri=https://oauth.vk.com/blank.html&scope=audio,offline&response_type=token&v=5.131"
private const val YA_URL = "https://oauth.yandex.ru/authorize?response_type=token" +
    "&client_id=23cabbbdc6cd418abb4b39c32c41195d"

class MainActivity : ComponentActivity() {
    private val vm by viewModels<MainVM>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) handle(intent)
        setContent { App(vm) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        i?.data?.let { if (it.scheme == "musicmover") vm.onSpotifyRedirect(it) }
    }
}

@Composable
fun App(vm: MainVM) {
    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(Modifier.fillMaxSize()) {
            if (vm.loginFor != null) LoginWeb(vm) else Main(vm)
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LoginWeb(vm: MainVM) {
    val id = vm.loginFor ?: return
    BackHandler { vm.loginFor = null }
    AndroidView(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                settings.userAgentString = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                webChromeClient = WebChromeClient()
                webViewClient = object : WebViewClient() {
                    private fun check(u: String?): Boolean {
                        if (vm.loginFor == null || u == null || !u.contains("access_token=")) return false
                        val tok = Regex("access_token=([^&]+)").find(u)?.groupValues?.get(1) ?: return false
                        vm.onToken(id, tok)
                        return true
                    }
                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = check(r.url.toString())
                    override fun onPageStarted(v: WebView?, u: String?, f: Bitmap?) { check(u) }
                }
                loadUrl(if (id == "vk") VK_URL else YA_URL)
            }
        },
    )
}

@Composable
fun Main(vm: MainVM) {
    @Suppress("UNUSED_VARIABLE") val tick = vm.tick
    val ctx = LocalContext.current
    val sources = SERVICE_NAMES.keys.filter { vm.connected(it) }
    val targets = sources.filter { it != "vk" && it != "file" }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.fileText = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readText()
    }

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { Text("MusicMover", style = MaterialTheme.typography.headlineMedium) }
        item { Text("1. Аккаунты", style = MaterialTheme.typography.titleMedium) }
        SERVICE_NAMES.filterKeys { it != "file" }.forEach { (id, name) ->
            item(key = "acc_$id") {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(name)
                        Text(
                            if (vm.connected(id)) "подключено" else "не подключено",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    if (vm.connected(id)) {
                        OutlinedButton(onClick = { vm.logout(id) }) { Text("Выйти") }
                    } else {
                        Button(
                            enabled = id != "spotify" || vm.spClient.isNotBlank(),
                            onClick = {
                                if (id == "spotify") SpotifyAuth.start(ctx, vm.store, vm.spClient.trim())
                                else vm.loginFor = id
                            },
                        ) { Text("Войти") }
                    }
                }
            }
            if (id == "spotify" && !vm.connected("spotify")) {
                item(key = "sp_client") {
                    Column {
                        OutlinedTextField(
                            value = vm.spClient, onValueChange = { vm.spClient = it },
                            label = { Text("Spotify Client ID") }, singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Text(
                            "В developer.spotify.com создай приложение и добавь Redirect URI: ${SpotifyAuth.REDIRECT}",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }

        item(key = "file_src") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Файл со списком треков")
                    Text(
                        if (vm.fileText != null) "загружен" else "строки «Исполнитель - Название», плейлисты с «# Название»",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                OutlinedButton(onClick = { picker.launch(arrayOf("text/*")) }) { Text("Выбрать") }
            }
        }

        item { Spacer(Modifier.height(8.dp)); Text("2. Откуда → куда", style = MaterialTheme.typography.titleMedium) }
        if (sources.isEmpty()) item { Text("Сначала подключи хотя бы два сервиса (VK — только как источник).") }
        item {
            Column {
                Text("Откуда", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    sources.forEach { id ->
                        FilterChip(
                            selected = vm.src == id,
                            onClick = { vm.src = id; vm.lists = emptyList(); if (vm.dst == id) vm.dst = null },
                            label = { Text(SERVICE_NAMES[id]!!) },
                        )
                    }
                }
                Text("Куда", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    targets.filter { it != vm.src }.forEach { id ->
                        FilterChip(
                            selected = vm.dst == id,
                            onClick = { vm.dst = id },
                            label = { Text(SERVICE_NAMES[id]!!) },
                        )
                    }
                }
            }
        }
        item {
            Button(enabled = vm.src != null && !vm.busy, onClick = { vm.loadLists() }) { Text("Загрузить плейлисты") }
        }

        if (vm.lists.isNotEmpty()) {
            item { Text("3. Что переносить", style = MaterialTheme.typography.titleMedium) }
            itemsIndexed(vm.lists) { i, it ->
                Row(
                    Modifier.fillMaxWidth().clickable { vm.toggle(i) },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Checkbox(checked = it.selected, onCheckedChange = { vm.toggle(i) })
                    Text(it.ref.name)
                }
            }
            item {
                Button(
                    enabled = !vm.busy && vm.dst != null && vm.lists.any { it.selected },
                    onClick = { vm.run() },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (vm.busy) "Выполняется…" else "Перенести") }
            }
        }

        if (vm.log.isNotEmpty()) {
            item { Text("Журнал", style = MaterialTheme.typography.titleMedium) }
            itemsIndexed(vm.log.toList()) { _, line -> Text(line, style = MaterialTheme.typography.bodySmall) }
        }
    }
}
