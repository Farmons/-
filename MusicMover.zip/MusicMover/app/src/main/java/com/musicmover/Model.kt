package com.musicmover

import android.content.Context
import okhttp3.FormBody
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

data class Track(
    val artist: String,
    val title: String,
    val durationSec: Int? = null,
    val id: String? = null,
    val albumId: String? = null,
)

/** id == null означает «Избранное» */
data class PlaylistRef(val id: String?, val name: String)

interface MusicService {
    suspend fun playlists(): List<PlaylistRef>
    suspend fun read(pid: String?): List<Track>
    suspend fun search(q: String): List<Track>
    suspend fun save(tracks: List<Track>, name: String, likes: Boolean)
}

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("mm", Context.MODE_PRIVATE)
    fun get(k: String): String? = p.getString(k, null)
    fun put(k: String, v: String) = p.edit().putString(k, v).apply()
    fun remove(vararg ks: String) = p.edit().apply { ks.forEach { remove(it) } }.apply()
}

object Http {
    private val client = OkHttpClient()

    fun url(base: String, vararg q: Pair<String, String>): String =
        base.toHttpUrl().newBuilder().apply { q.forEach { addQueryParameter(it.first, it.second) } }.build().toString()

    fun request(
        method: String, url: String, headers: Map<String, String> = emptyMap(),
        form: Map<String, String>? = null, json: String? = null,
    ): String {
        for (attempt in 0..2) {
            val body: RequestBody? = when {
                form != null -> FormBody.Builder().apply { form.forEach { (k, v) -> add(k, v) } }.build()
                json != null -> json.toRequestBody("application/json".toMediaType())
                method == "POST" || method == "PUT" -> "".toRequestBody(null)
                else -> null
            }
            val req = Request.Builder().url(url).method(method, body)
                .apply { headers.forEach { (k, v) -> header(k, v) } }.build()
            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (resp.code == 429 && attempt < 2) {
                    Thread.sleep(((resp.header("Retry-After")?.toLongOrNull() ?: 2L) + 1L) * 1000L)
                } else if (!resp.isSuccessful) {
                    throw IOException("HTTP ${resp.code}: ${text.take(200)}")
                } else {
                    return text
                }
            }
        }
        throw IOException("Слишком много запросов")
    }

    fun obj(
        method: String, url: String, headers: Map<String, String> = emptyMap(),
        form: Map<String, String>? = null, json: String? = null,
    ): JSONObject = request(method, url, headers, form, json).let { if (it.isBlank()) JSONObject() else JSONObject(it) }
}

object Matcher {
    fun norm(s: String): String = s.lowercase()
        .replace(Regex("\\(.*?\\)|\\[.*?\\]"), " ")
        .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
        .replace(Regex("\\s+"), " ").trim()

    private fun lev(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            }
            prev = cur
        }
        return prev[b.length]
    }

    fun sim(a: String, b: String): Double {
        val x = norm(a); val y = norm(b)
        if (x.isEmpty() && y.isEmpty()) return 1.0
        return 1.0 - lev(x, y).toDouble() / maxOf(x.length, y.length)
    }

    private fun artistSim(a: String, b: String): Double {
        val x = norm(a); val y = norm(b)
        if (x.length > 2 && y.length > 2 && (x.contains(y) || y.contains(x))) return 1.0
        return sim(a, b)
    }

    fun best(want: Track, cands: List<Track>, threshold: Double = 0.72): Track? {
        var best: Track? = null
        var bestScore = 0.0
        for (c in cands) {
            var s = 0.6 * sim(want.title, c.title)
            s += if (want.artist.isNotBlank()) 0.4 * artistSim(want.artist, c.artist) else 0.4
            val wd = want.durationSec; val cd = c.durationSec
            if (wd != null && cd != null && kotlin.math.abs(wd - cd) > 7) s -= 0.15
            if (s > bestScore) { best = c; bestScore = s }
        }
        return if (bestScore >= threshold) best else null
    }
}
