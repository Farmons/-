package com.musicmover

import org.json.JSONArray
import org.json.JSONObject

class YandexService(token: String) : MusicService {
    private val base = "https://api.music.yandex.net"
    private val h = mapOf(
        "Authorization" to "OAuth $token",
        "X-Yandex-Music-Client" to "YandexMusicAndroid/24023621",
    )
    private val uid: String by lazy {
        Http.obj("GET", "$base/account/status", h).getJSONObject("result").getJSONObject("account").get("uid").toString()
    }

    private fun conv(t: JSONObject): Track {
        val artists = t.optJSONArray("artists")
        val names = (0 until (artists?.length() ?: 0)).joinToString(", ") { artists!!.getJSONObject(it).optString("name") }
        val album = t.optJSONArray("albums")?.optJSONObject(0)?.opt("id")?.toString()
        return Track(names, t.optString("title"), t.optInt("durationMs") / 1000, t.get("id").toString(), album)
    }

    private fun fetchByIds(ids: List<String>): List<Track> =
        ids.chunked(100).flatMap { chunk ->
            val arr = Http.obj("POST", "$base/tracks", h, form = mapOf("track-ids" to chunk.joinToString(",")))
                .optJSONArray("result") ?: JSONArray()
            (0 until arr.length()).map { conv(arr.getJSONObject(it)) }
        }

    override suspend fun playlists(): List<PlaylistRef> {
        val arr = Http.obj("GET", "$base/users/$uid/playlists/list", h).getJSONArray("result")
        return (0 until arr.length()).map {
            val p = arr.getJSONObject(it)
            PlaylistRef(p.get("kind").toString(), p.getString("title"))
        }
    }

    override suspend fun read(pid: String?): List<Track> {
        if (pid == null) {
            val arr = Http.obj("GET", "$base/users/$uid/likes/tracks", h)
                .getJSONObject("result").getJSONObject("library").getJSONArray("tracks")
            val ids = (0 until arr.length()).map {
                val t = arr.getJSONObject(it)
                "${t.get("id")}:${t.opt("albumId")}"
            }
            return fetchByIds(ids)
        }
        val arr = Http.obj("GET", "$base/users/$uid/playlists/$pid", h)
            .getJSONObject("result").optJSONArray("tracks") ?: return emptyList()
        val full = mutableListOf<Track>()
        val short = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val e = arr.getJSONObject(i)
            val t = e.optJSONObject("track")
            if (t != null) full += conv(t) else short += "${e.get("id")}:${e.opt("albumId")}"
        }
        return full + fetchByIds(short)
    }

    override suspend fun search(q: String): List<Track> {
        val o = Http.obj("GET", Http.url("$base/search", "text" to q, "type" to "track", "page" to "0"), h)
        val arr = o.optJSONObject("result")?.optJSONObject("tracks")?.optJSONArray("results") ?: return emptyList()
        return (0 until minOf(arr.length(), 10)).map { conv(arr.getJSONObject(it)) }
    }

    override suspend fun save(tracks: List<Track>, name: String, likes: Boolean) {
        val usable = tracks.filter { it.id != null && it.albumId != null }
        if (likes) {
            usable.chunked(100).forEach { chunk ->
                Http.request("POST", "$base/users/$uid/likes/tracks/add-multiple", h,
                    form = mapOf("track-ids" to chunk.joinToString(",") { "${it.id}:${it.albumId}" }))
            }
            return
        }
        val created = Http.obj("POST", "$base/users/$uid/playlists/create", h,
            form = mapOf("title" to name, "visibility" to "private")).getJSONObject("result")
        val kind = created.get("kind").toString()
        var revision = created.optInt("revision", 1)
        var inserted = 0
        usable.chunked(50).forEach { chunk ->
            val diff = JSONArray().put(
                JSONObject().put("op", "insert").put("at", inserted).put(
                    "tracks", JSONArray(chunk.map { JSONObject().put("id", it.id).put("albumId", it.albumId) })
                )
            )
            val res = Http.obj("POST", "$base/users/$uid/playlists/$kind/change", h,
                form = mapOf("kind" to kind, "revision" to revision.toString(), "diff" to diff.toString()))
            revision = res.optJSONObject("result")?.optInt("revision", revision + 1) ?: (revision + 1)
            inserted += chunk.size
        }
    }
}
