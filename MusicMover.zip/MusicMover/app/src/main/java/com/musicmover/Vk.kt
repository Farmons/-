package com.musicmover

import org.json.JSONObject
import java.io.IOException

/** VK Музыка: только источник. Доступ неофициальный. */
class VkService(private val token: String) : MusicService {
    private val ua = "KateMobileAndroid/56 lite-460 (Android 4.4.2; SDK 19; x86; unknown Android SDK built for x86; en)"

    private fun call(method: String, vararg p: Pair<String, String>): JSONObject {
        Thread.sleep(350)
        val o = Http.obj(
            "GET", Http.url("https://api.vk.com/method/$method", "access_token" to token, "v" to "5.131", *p),
            mapOf("User-Agent" to ua),
        )
        o.optJSONObject("error")?.let { throw IOException("VK: ${it.optString("error_msg")}") }
        return o
    }

    private val owner: String by lazy {
        call("users.get").getJSONArray("response").getJSONObject(0).get("id").toString()
    }

    override suspend fun playlists(): List<PlaylistRef> {
        val out = mutableListOf<PlaylistRef>()
        var offset = 0
        while (true) {
            val items = call("audio.getPlaylists", "owner_id" to owner, "count" to "100", "offset" to offset.toString())
                .getJSONObject("response").getJSONArray("items")
            if (items.length() == 0) return out
            for (i in 0 until items.length()) {
                val p = items.getJSONObject(i)
                out += PlaylistRef("${p.get("owner_id")}_${p.get("id")}_${p.optString("access_key")}", p.getString("title"))
            }
            offset += items.length()
        }
    }

    override suspend fun read(pid: String?): List<Track> {
        val out = mutableListOf<Track>()
        var offset = 0
        val extra = mutableListOf<Pair<String, String>>()
        if (pid != null) {
            val parts = pid.split("_")
            extra += "owner_id" to parts[0]
            extra += "playlist_id" to parts[1]
            if (parts.size > 2 && parts[2].isNotEmpty()) extra += "access_key" to parts[2]
        }
        while (true) {
            val items = call("audio.get", "count" to "200", "offset" to offset.toString(), *extra.toTypedArray())
                .getJSONObject("response").getJSONArray("items")
            if (items.length() == 0) return out
            for (i in 0 until items.length()) {
                val t = items.getJSONObject(i)
                out += Track(t.optString("artist"), t.optString("title"), t.optInt("duration"))
            }
            offset += items.length()
        }
    }

    override suspend fun search(q: String): List<Track> = throw UnsupportedOperationException("VK — только источник")
    override suspend fun save(tracks: List<Track>, name: String, likes: Boolean) =
        throw UnsupportedOperationException("VK — только источник")
}
