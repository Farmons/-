# MusicMover (Android)

Перенос плейлистов и избранного: VK / Яндекс Музыка / Spotify → Яндекс Музыка / Spotify.

## Сборка
1. Установи Android Studio (Ladybug или новее).
2. File → Open → папка MusicMover. Дождись Gradle Sync.
3. Подключи телефон (отладка по USB) и нажми Run, либо Build → Build APK(s).

## Spotify
- developer.spotify.com/dashboard → Create app.
- Redirect URI: musicmover://spotify
- Включи в «Users and access» свой аккаунт. Нужен Spotify Premium (требование Dev Mode).
- В приложении вставь Client ID и нажми «Войти».

## VK и Яндекс
Вход через веб-форму в приложении, пароль приложению не передаётся. Доступ неофициальный и может перестать работать.
